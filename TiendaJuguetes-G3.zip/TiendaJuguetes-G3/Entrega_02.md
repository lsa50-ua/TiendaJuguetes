# Comentarios Entrega 02

Muy bien, la entrega es correcta.

## Comentarios Base de datos
Veo que habeis creado las entidades Carrito y Factura. Estas, para un correcto funcionamiento, deberian tener las entidades LineaFactura y LineaCarrito. De esta manera, un usuario va añadiendo artículos al carrito y al formalizar el pedido, el carrito se convierte en pedido. De la misma manera, al solicitar la factura, el pedido se convierte en factura. Estos tres elementos necesitan de sus correspondientes líneas.

## Comentarios proyecto GitHub
No se si es debido al cambio pero teneis que crear un proyecto en GitHub e ir asignando las tareas a cada componente del grupo. Al pincipio parece un poco tedioso e incluso inecesario, pero tenemos que ir acostumbrandonos a gestionar bien en trabajo en grupo. En las próximas entregas debeis crear el proyecto y asignar las tareas a cada componente.

## Comentarios Commits

Recordad que cuando hagais un commit, debeis especificar vuestro DNI: DNI - COMENTARIO

Un saludo y seguid así. Buen trabajo.